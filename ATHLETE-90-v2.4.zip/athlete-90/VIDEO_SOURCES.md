# منابع ویدئویی ATHLETE 90

ویدئوها درون برنامه از طریق `youtube-nocookie.com` بارگذاری می‌شوند. فایل‌ها کپی، دانلود یا بازنشر نشده‌اند؛ حقوق ویدئو متعلق به سازنده و کانال اصلی است. `شروع` زمان شروع پخش در ثانیه است.

| حرکت در ATHLETE 90 | ویدئو / سازنده | شروع | نوع تطابق |
|---|---|---:|---|
| شنا معمولی | [How to Start CALISTHENICS at HOME](https://www.youtube.com/watch?v=2uYurS37svo) · PetruWorkout | 72 | بخش آموزش انواع شنا |
| شنا دست باز | همان ویدئوی PetruWorkout | 72 | بخش آموزش انواع شنا |
| شنا پایک | [Pike Push Up Tutorial](https://www.youtube.com/watch?v=3r3tvRF1tVA) · Vitaly Pavlenko | 0 | آموزش اختصاصی |
| شنا دست جمع | ویدئوی PetruWorkout | 72 | بخش آموزش انواع شنا |
| پلانک | [How to Plank Properly](https://www.youtube.com/watch?v=8b13VkLlHeo) · Yes2Next | 362 | اجرای پلانک روی زمین |
| اسکوات | [Bodyweight Squat Tutorial](https://www.youtube.com/watch?v=P-yaD24bUE8) · Runna | 0 | آموزش اختصاصی |
| لانج معکوس | [How To Do A Reverse Lunge Correctly](https://www.youtube.com/watch?v=-Nr6dqEvz3Q) · Jack Hanrahan Fitness | 0 | آموزش اختصاصی |
| اسکوات پرشی | [30 Min No Repeats HIIT](https://www.youtube.com/watch?v=kJ-3g9pzJdQ) · TIFF x DAN | 1790 | بخش Jump Squats |
| ساق پا ایستاده | [How to Start CALISTHENICS at HOME](https://www.youtube.com/watch?v=2uYurS37svo) · PetruWorkout | 1498 | بخش حرکات پایه پا |
| پل باسن | ویدئوی PetruWorkout | 1498 | بخش حرکات پایه پا |
| نشستن کنار دیوار | [Wall Sit Tutorial](https://www.youtube.com/watch?v=JQ2JBphtUk8) · FIT.nl | 0 | آموزش اختصاصی |
| زانو بلند درجا | [30 Min No Repeats HIIT](https://www.youtube.com/watch?v=kJ-3g9pzJdQ) · TIFF x DAN | 230 | بخش High Knees |
| پا سریع درجا | [How To Do FAST FEET](https://www.youtube.com/embed/eT5M1goPDhY) · Hambleton Athletics | 0 | آموزش اختصاصی |
| استارت انفجاری از حالت نیم‌قدم | [Sprint from a Split Stance](https://www.youtube.com/watch?v=cip8lzxErWs) · PLAE | 0 | آموزش اختصاصی |
| کوهنوردی | ویدئوی TIFF x DAN | 650 | بخش Mountain Climbers |
| پرش اسکیت‌باز | ویدئوی TIFF x DAN | 1250 | بخش Speed Skaters |
| درازنشست | [How to Start CALISTHENICS at HOME](https://www.youtube.com/watch?v=2uYurS37svo) · PetruWorkout | 975 | بخش تمرینات پایه شکم |
| کرانچ شکم | ویدئوی PetruWorkout | 975 | بخش تمرینات پایه شکم |
| بالا آوردن پا خوابیده | ویدئوی PetruWorkout | 975 | بخش تمرینات پایه شکم |
| پلانک بغل | ویدئوی PetruWorkout | 1307 | بخش تمرینات پیشرفته شکم / Side Plank |
| سوپرمن | [Exercise Tutorial – Superman](https://www.youtube.com/watch?v=z6PJMT2y8GQ) · BarBend | 0 | آموزش اختصاصی |
| فرشته برعکس | [Paradiso CrossFit Prehab – Reverse Snow Angel](https://www.youtube.com/watch?v=Rwm7QgLllSA) · Paradiso CrossFit | 0 | آموزش اختصاصی |
| پرنده و سگ | [Bird Dog Exercise](https://www.youtube.com/watch?v=sjUe5KpzyU4) · FITBODY with Julie Lohre | 0 | آموزش اختصاصی |
| جلو بازوی خودمقاومتی با حوله | [Build Bigger Biceps With a Towel](https://www.youtube.com/watch?v=Lkm-KHN3x3o) · CAPTAIN CHAD | 0 | آموزش اختصاصی |
| راه رفتن سریع درجا | ویدئوی TIFF x DAN | 230 | بخش High Knees / High Knee March |
| راه رفتن آرام در خانه | [20-Minute Walk at Home](https://www.youtube.com/watch?v=IA9yH2994vY) · Improved Health | 3 | تمرین پیاده‌روی داخل خانه |
| کشش ملایم پا و لگن | [15 Min Full Body Stretch](https://www.youtube.com/watch?v=oY2jk_a3k9U) · Dr. Melissa Oleson | 0 | روتین کشش و موبیلیتی کل بدن |

## نکته مهم درباره تطابق

برای حرکت‌هایی که در یک ویدئوی چندحرکتی آموزش داده می‌شوند، برنامه از زمان شروع همان بخش استفاده می‌کند و در توضیح حرکت نام بخش را نشان می‌دهد. استارت انفجاری در نسخه ۲.۴ به حالت نیم‌قدم اصلاح شده تا با ویدئوی آموزشی اختصاصی PLAE تطابق داشته باشد. این تمرین در فضای کوتاه با یک تا سه قدم و توقف کنترل‌شده اجرا می‌شود.

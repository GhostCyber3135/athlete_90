window.Plans = {
0:{day:"شنبه",title:"سینه، شانه و پشت بازو",duration:"۳۰ تا ۴۰ دقیقه",items:["pushup","wide","pike","close","plank"]},
1:{day:"یکشنبه",title:"پا، باسن و قدرت انفجاری",duration:"۳۵ تا ۴۵ دقیقه",items:["squat","lunge","jump","calf","bridge","wall"]},
2:{day:"دوشنبه",title:"ریکاوری و انعطاف‌پذیری",duration:"۱۵ دقیقه",items:["walk","stretch"]},
3:{day:"سه‌شنبه",title:"سرعت، شتاب و استقامت خانگی",duration:"۳۰ تا ۳۵ دقیقه",items:["high","fast","start","mountain","skater","march"]},
4:{day:"چهارشنبه",title:"شکم، پشت و بازو",duration:"۳۰ تا ۴۰ دقیقه",items:["situp","crunch","legraise","side","superman","snow","curl"]},
5:{day:"پنجشنبه",title:"تمرین ترکیبی کل بدن",duration:"۲۵ تا ۳۵ دقیقه",items:["pushup","squat","lunge","pike","bird","plank"]},
6:{day:"جمعه",title:"استراحت کامل",duration:"ریکاوری",items:[]}
};
Store.load();
function dayIndex(){return (new Date().getDay()+1)%7}
function modal(html){document.getElementById("modalContent").innerHTML=html;document.getElementById("modalBackdrop").classList.add("open");document.getElementById("modalBackdrop").setAttribute("aria-hidden","false")}
function closeModal(){const frame=document.querySelector("#modalContent iframe");if(frame)frame.src="about:blank";document.getElementById("modalBackdrop").classList.remove("open");document.getElementById("modalBackdrop").setAttribute("aria-hidden","true")}
let toastTimer;function toast(t){const x=document.getElementById("toast");x.textContent=t;x.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>x.classList.remove("show"),2300)}
function renderAll(){
 const idx=dayIndex(),p=Plans[idx],date=new Date();document.getElementById("todayDate").textContent=new Intl.DateTimeFormat("fa-IR",{weekday:"long",day:"numeric",month:"long"}).format(date);
 const labels=["ش","ی","د","س","چ","پ","ج"],days=Array.from({length:7},(_,i)=>{let d=new Date();d.setDate(d.getDate()-((d.getDay()+1)%7)+i);let key=localDate(d);return `<div class="day-chip ${i===idx?"today":""} ${Store.data.completedDays.includes(key)?"done":""}"><span>${labels[i]}</span><b>${new Intl.NumberFormat("fa-IR").format(d.getDate())}</b></div>`}).join("");document.getElementById("weekStrip").innerHTML=days;
 document.getElementById("todayCard").innerHTML=`<div><span class="eyebrow">${p.day} · ${p.duration}</span><h3>${p.title}</h3><p>${p.items.length?`${p.items.length} حرکت در برنامه امروز`:"امروز به بدنت فرصت ریکاوری بده."}</p></div><button class="round-arrow" id="todayGo">${p.items.length?"←":"✓"}</button>`;document.getElementById("todayGo").onclick=()=>p.items.length?Workout.start(idx):toast("امروز روز استراحت است.");
 document.getElementById("weekList").innerHTML=Object.entries(Plans).map(([i,x])=>`<article class="day-card"><div class="day-number">${x.day.slice(0,1)}</div><div><h3>${x.day} · ${x.title}</h3><p>${x.items.length?x.items.length+" حرکت · "+x.duration:"استراحت و ریکاوری"}</p></div><button data-day="${i}">${x.items.length?"مشاهده و شروع":"روز استراحت"}</button></article>`).join("");
 document.querySelectorAll("[data-day]").forEach(b=>b.onclick=()=>{let i=+b.dataset.day;if(Plans[i].items.length)Workout.start(i);else toast("روز استراحت؛ ریکاوری هم بخشی از برنامه است.")});
 Progress.render();renderExercises();document.getElementById("journal").value=Store.data.journal||"";
}
function videoPanel(e,mode="detail"){
 const v=e.video;
 if(!v) return `<section class="video-unavailable"><div class="video-unavailable-icon">▶</div><b>ویدئوی تأییدشده در دسترس نیست</b><small>برای این حرکت فعلاً ویدئوی دقیق و قابل‌اعتماد پیدا نشده؛ به‌جای نمایش حرکت اشتباه، راهنمای متنی را نگه داشته‌ایم.</small></section>`;
 const sourceUrl=`https://www.youtube.com/watch?v=${encodeURIComponent(v.id)}${v.start?`&t=${v.start}s`:""}`;
 const player=`<div class="exercise-video-wrap"><div class="video-frame"><iframe title="${e.name} - ${v.title}" src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.id)}?start=${Math.max(0,Number(v.start)||0)}&rel=0&modestbranding=1" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div><div class="video-caption"><span class="video-live-dot"></span><span>${v.title} · ${v.creator}</span><a href="${sourceUrl}" target="_blank" rel="noopener noreferrer">باز کردن در یوتیوب ↗</a></div></div>`;
 return `<section class="exercise-demo" aria-label="ویدئوی آموزش ${e.name}"><div class="demo-heading"><span>اجرای حرکت توسط مربی</span><small>VIDEO COACH</small></div>${player}<p class="demo-note">${v.match||"ویدئوی آموزشی"} · برای پخش ویدئو به اینترنت نیاز است. ویدئو از یوتیوب بارگذاری می‌شود و داخل برنامه ذخیره نشده است.</p></section>`;
}
function renderExercises(filter="همه",q=""){
 const cats=["همه",...new Set(Exercises.map(e=>e.cat))];
 document.getElementById("exerciseFilters").innerHTML=cats.map(c=>`<button class="filter-btn ${c===filter?"active":""}" data-filter="${c}">${c}</button>`).join("");
 document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>renderExercises(b.dataset.filter,document.getElementById("exerciseSearch").value));
 const list=Exercises.filter(e=>(filter==="همه"||e.cat===filter)&&(`${e.name} ${e.en} ${e.muscles}`).toLowerCase().includes(q.toLowerCase()));
 document.getElementById("exerciseGrid").innerHTML=list.map(e=>{
  const thumb=e.video?.kind==="youtube"?`style="background-image:linear-gradient(180deg,#0000,#0009),url(https://img.youtube.com/vi/${e.video.id}/hqdefault.jpg)"`:"";
  return `<article class="exercise-card" data-ex="${e.id}" role="button" tabindex="0" aria-label="مشاهده آموزش ${e.name}"><div class="exercise-card-media ${e.video?"has-video":"no-video"}" ${thumb}><span class="media-play">▶</span><small>${e.video?"ویدئوی آموزشی":"راهنمای متنی"}</small></div><div class="exercise-card-body"><h3>${e.name}</h3><p>${e.cat} · ${e.reps}</p></div></article>`;
 }).join("")||`<div class="empty-state">حرکتی پیدا نشد.</div>`;
 document.querySelectorAll("[data-ex]").forEach(c=>{c.onclick=()=>showExercise(c.dataset.ex);c.onkeydown=event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();showExercise(c.dataset.ex)}}});
}
function showExercise(id){const e=Exercises.find(x=>x.id===id);modal(`<span class="eyebrow">${e.en}</span><h2>${e.name}</h2>${videoPanel(e)}<p class="workout-tip">${e.tip}</p><div class="exercise-meta"><span>عضلات: ${e.muscles}</span><span>${e.sets} ست · ${e.reps}</span></div><h3>روش اجرا</h3><ol class="detail-list">${e.steps.map(x=>`<li>${x}</li>`).join("")}</ol><h3>اشتباهات رایج</h3><p class="muted">${e.mistakes}</p><p class="muted">نسخه آسان‌تر: ${e.easy} · نسخه سخت‌تر: ${e.hard}</p><button class="btn btn-primary" id="detailClose">متوجه شدم</button>`);document.getElementById("detailClose").onclick=closeModal}
document.querySelectorAll("[data-nav]").forEach(b=>b.addEventListener("click",e=>{e.preventDefault();Navigation.go(b.dataset.nav)}));
document.getElementById("startToday").onclick=()=>Workout.startToday();
function requestModalClose(){
 if(Workout?.state){
  if(confirm("تمرین در حال اجراست. با بستن پنجره، تمرین نیمه‌تمام ذخیره شود؟")) Workout.finish(true);
 } else closeModal();
}
document.getElementById("modalClose").onclick=requestModalClose;
document.getElementById("modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")requestModalClose()};
document.getElementById("exerciseSearch").oninput=e=>renderExercises("همه",e.target.value);
document.getElementById("themeBtn").onclick=()=>{document.body.classList.toggle("light");Store.data.settings.theme=document.body.classList.contains("light")?"light":"dark";Store.save()};
document.getElementById("saveJournal").onclick=()=>{Store.data.journal=document.getElementById("journal").value;Store.save();toast("یادداشت ذخیره شد.")};
document.getElementById("breathStart").onclick=()=>Mental.start();
document.getElementById("addRecordBtn").onclick=()=>{modal(`<h2>ثبت رکورد شخصی</h2><p class="muted">عدد جدید را وارد کن. فقط رکوردهای واقعی خودت را ثبت کن.</p><label>نوع رکورد<select id="recordType" class="form-control"><option value="pushups">شنا</option><option value="squats">اسکوات</option><option value="situps">درازنشست</option><option value="plank">پلانک (ثانیه)</option></select></label><label>مقدار<input id="recordValue" type="number" min="0" class="form-control" placeholder="مثلاً ۱۵"></label><button class="btn btn-primary" id="saveRecord">ذخیره رکورد</button>`);document.getElementById("saveRecord").onclick=()=>{let k=document.getElementById("recordType").value,v=+document.getElementById("recordValue").value;if(v>0){Store.data.records[k]=Math.max(v,Store.data.records[k]||0);Store.save();Progress.render();closeModal();toast("رکورد ذخیره شد.")}}};
function exportData(){Store.export();toast("فایل پشتیبان آماده شد.")}document.getElementById("exportBtn").onclick=exportData;document.getElementById("exportBtn2").onclick=exportData;
document.getElementById("importFile").onchange=async e=>{try{const f=e.target.files[0];if(f){Store.import(JSON.parse(await f.text()));renderAll();toast("اطلاعات بازیابی شد.")}}catch(err){toast("فایل پشتیبان معتبر نیست.")}};
document.getElementById("resetBtn").onclick=()=>{if(confirm("تمام تمرین‌ها، رکوردها و یادداشت‌ها پاک شوند؟ این کار قابل بازگشت نیست.")){localStorage.removeItem(Store.key);Store.load();renderAll();toast("اطلاعات پاک شد.")}};
document.getElementById("soundSetting").checked=Store.data.settings.sound;document.getElementById("restSetting").checked=Store.data.settings.rest;document.getElementById("restDuration").value=Store.data.settings.restDuration;
document.getElementById("soundSetting").onchange=e=>{Store.data.settings.sound=e.target.checked;Store.save()};document.getElementById("restSetting").onchange=e=>{Store.data.settings.rest=e.target.checked;Store.save()};document.getElementById("restDuration").onchange=e=>{Store.data.settings.restDuration=Math.max(15,Math.min(240,+e.target.value||60));Store.save()};
document.getElementById("profileBtn").onclick=()=>Navigation.go("settings");
if(Store.data.settings.theme==="light")document.body.classList.add("light");

renderAll();
if("serviceWorker" in navigator && location.protocol!=="file:" && !window.Capacitor?.isNativePlatform?.())window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(console.warn));

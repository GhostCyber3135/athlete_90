const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.resolve(__dirname, "..");
const read = (p) => fs.readFileSync(path.join(root, p), "utf8");

function createContext() {
  const ctx = {
    console, Date, Math, Array, Set, Intl,
    clearInterval() {},
    setInterval() { return 1; },
    document: {
      els: {},
      getElementById(id) {
        return this.els[id] || (this.els[id] = { textContent: "", onclick: null, disabled: false });
      }
    },
    Plans: {
      0: { day: "شنبه", title: "جلسه آزمایشی", items: ["pushup"] },
      6: { day: "جمعه", title: "ریکاوری", items: [] }
    },
    Store: {
      data: { settings: { rest: false, restDuration: 60, sound: false } },
      addSession(session) { this.lastSession = session; },
      load() {}
    },
    toast(message) { ctx.lastToast = message; },
    modal(html) {
      ctx.lastModal = html;
      for (const id of ["completeSet", "pauseWorkout", "skipExercise", "stopWorkout", "skipRest", "pauseFromRest"]) {
        ctx.document.els[id] = { textContent: "", onclick: null, disabled: false };
      }
    },
    closeModal() { ctx.didClose = true; },
    renderAll() {},
    localDate() { return "2026-11-21"; },
    confirm() { return true; }
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(read("js/exercise-library.js"), ctx);
  const appSource = read("app.js");
  const videoFunction = appSource.slice(appSource.indexOf("function videoPanel("), appSource.indexOf("function renderExercises("));
  vm.runInContext(videoFunction, ctx);
  vm.runInContext(read("js/workout-engine.js"), ctx);
  return ctx;
}

test("every planned exercise exists in the exercise library", () => {
  const ctx = createContext();
  vm.runInContext(read("app.js").split("Store.load();")[0], ctx);
  const ids = new Set(ctx.Exercises.map((exercise) => exercise.id));
  for (const [day, plan] of Object.entries(ctx.Plans)) {
    for (const id of plan.items) assert.ok(ids.has(id), `missing exercise ${id} in day ${day}`);
  }
});

test("every exercise has a curated video entry", () => {
  const ctx = createContext();
  assert.ok(ctx.Exercises.length >= 25);
  for (const exercise of ctx.Exercises) {
    assert.ok(exercise.video, `missing video for ${exercise.id}`);
    assert.equal(exercise.video.kind, "youtube");
    assert.match(exercise.video.id, /^[A-Za-z0-9_-]{11}$/);
    assert.ok(Number.isInteger(exercise.video.start) && exercise.video.start >= 0, `invalid start time for ${exercise.id}`);
    assert.ok(exercise.video.title && exercise.video.creator && exercise.video.match, `incomplete attribution for ${exercise.id}`);
    assert.match(ctx.videoPanel(exercise), /youtube-nocookie\.com\/embed/);
  }
});

test("video catalog covers all movements used by the weekly plan", () => {
  const ctx = createContext();
  vm.runInContext(read("app.js").split("Store.load();")[0], ctx);
  const ids = new Set(ctx.Exercises.map((exercise) => exercise.id));
  for (const plan of Object.values(ctx.Plans)) for (const id of plan.items) assert.ok(ids.has(id));
  for (const exercise of ctx.Exercises) assert.ok(exercise.video?.id, `no coach video for ${exercise.name}`);
  assert.equal(new Set(ctx.Exercises.map(exercise => exercise.video.id)).size, 15);
});

test("app no longer renders the old line-art SVG coach", () => {
  const html = read("index.html");
  const app = read("app.js");
  assert.doesNotMatch(html, /animation-engine\.js/);
  assert.doesNotMatch(app, /Character\.svg/);
  assert.equal(fs.existsSync(path.join(root, "js/animation-engine.js")), false);
  assert.match(app, /youtube-nocookie\.com\/embed/);
});

test("rest day is rejected clearly; workout starts and saves a completed set", () => {
  const ctx = createContext();
  assert.equal(ctx.Workout.start(6), false);
  assert.match(ctx.lastToast, /ریکاوری/);
  assert.equal(ctx.Workout.start(0), true);
  assert.match(ctx.lastModal, /youtube-nocookie\.com\/embed/);
  ctx.document.els.completeSet.onclick();
  ctx.document.els.completeSet.onclick();
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state, null);
  assert.equal(ctx.Store.lastSession.sets, 3);
  assert.equal(ctx.didClose, true);
});

test("home start button starts the next workout on a rest day", () => {
  const ctx = createContext();
  const NativeDate = Date;
  class Friday extends NativeDate { getDay() { return 5; } }
  ctx.Date = Friday;
  assert.equal(ctx.Workout.startToday(), true);
  assert.equal(ctx.Workout.state.day, 0);
  assert.match(ctx.lastToast, /جمعه.*شنبه/);
});

test("pause blocks set completion and resume restores workout controls", () => {
  const ctx = createContext();
  assert.equal(ctx.Workout.start(0), true);
  ctx.document.els.pauseWorkout.onclick();
  assert.equal(ctx.Workout.state.paused, true);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state.completedSets, 0);
  ctx.document.els.pauseWorkout.onclick();
  assert.equal(ctx.Workout.state.paused, false);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state.completedSets, 1);
});

test("rest countdown can be paused and resumed without losing its remaining time", () => {
  const ctx = createContext();
  ctx.Store.data.settings.rest = true;
  assert.equal(ctx.Workout.start(0), true);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.inRest, true);
  const before = ctx.Workout.restRemaining;
  ctx.document.els.pauseFromRest.onclick();
  assert.equal(ctx.Workout.state.paused, true);
  assert.ok(ctx.Workout.restRemaining <= before);
  ctx.document.els.pauseFromRest.onclick();
  assert.equal(ctx.Workout.state.paused, false);
  assert.equal(ctx.Workout.inRest, true);
  ctx.Workout.finish(true);
});

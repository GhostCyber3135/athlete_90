window.Mental = {
 timer:null,cycle:0,phase:0,
 start(){clearInterval(this.timer);this.cycle=0;this.phase=0;this.step()},
 step(){const circle=document.getElementById("breathCircle"),txt=document.getElementById("breathText"),hint=document.getElementById("breathHint");if(!txt)return;if(this.cycle>=5){txt.textContent="تمام شد";hint.textContent="خوب بود. حالا روی سه هدف ساده بازی تمرکز کن.";clearInterval(this.timer);return}
 const inhale=this.phase===0;txt.textContent=inhale?"دم آرام":"بازدم آرام";hint.textContent=`چرخه ${this.cycle+1} از ۵ · ${inhale?"۴ ثانیه دم":"۶ ثانیه بازدم"}`;circle.classList.toggle("inhale",inhale);circle.classList.toggle("exhale",!inhale);let count=inhale?4:6;let start=Date.now();clearInterval(this.timer);this.timer=setInterval(()=>{if(Date.now()-start>=count*1000){clearInterval(this.timer);if(this.phase===0)this.phase=1;else{this.phase=0;this.cycle++}this.step()}},100)}
};
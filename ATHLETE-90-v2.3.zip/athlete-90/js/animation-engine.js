/* ATHLETE 90 articulated exercise guide. The drawings are simplified teaching
   illustrations; motion is deliberately slow and looped for form recognition. */
let athleteSvgSerial = 0;
window.Character = {
  svg(type = "idle", compact = false) {
    const exercise = window.Exercises?.find(item => item.id === type);
    const exerciseId = exercise ? exercise.id : type;
    if (exercise) type = exercise.type;
    const filterId = `athleteGlow${++athleteSvgSerial}`;
    const horizontal = ["pushup", "plank", "mountain", "bird", "superman"].includes(type);
    const styles = {
      idle: "athlete-idle", pushup: "athlete-pushup", squat: "athlete-squat",
      situp: "athlete-situp", highknees: "athlete-run", plank: "athlete-plank",
      lunge: "athlete-lunge", mountain: "athlete-mountain", stretch: "athlete-stretch",
      bridge: "athlete-bridge", calf: "athlete-calf", wall: "athlete-wall",
      bird: "athlete-bird", superman: "athlete-superman", snow: "athlete-stretch", snow: "athlete-stretch"
    };
    const cls = styles[type] || "athlete-idle";
    const idClass = `move-${String(exerciseId).replace(/[^a-z0-9_-]/gi, "")}`;
    const floor = horizontal ? `<path d="M18 190H182"/>` : `<path d="M24 211H176"/>`;
    const figure = horizontal ? `
      <g class="torso"><path d="M65 104 Q98 91 130 108"/></g>
      <circle class="head" cx="148" cy="100" r="15"/>
      <g class="arm arm-a"><path d="M75 105 L52 139 L34 177"/></g>
      <g class="arm arm-b"><path d="M82 106 L62 143 L48 177"/></g>
      <g class="leg leg-a"><path d="M65 104 L42 130 L25 165"/></g>
      <g class="leg leg-b"><path d="M110 105 L143 127 L176 159"/></g>
    ` : `
      <circle class="head" cx="100" cy="39" r="17"/>
      <g class="torso"><path d="M100 59 Q91 91 100 121"/></g>
      <g class="arm arm-a"><path d="M96 72 L72 100 L58 126"/></g>
      <g class="arm arm-b"><path d="M104 72 L128 99 L143 125"/></g>
      <g class="leg leg-a"><path d="M96 119 L77 160 L69 202"/></g>
      <g class="leg leg-b"><path d="M104 119 L124 160 L132 202"/></g>
    `;
    const extra = type === "situp" ? `<path class="mat" d="M22 196H178"/>` : "";
    return `<svg class="athlete-svg ${cls} ${idClass}" viewBox="0 0 200 225" role="img" aria-label="نمایش متحرک شماتیک حرکت ${type}" xmlns="http://www.w3.org/2000/svg">
      <defs><filter id="${filterId}"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
      <g class="ground" fill="none" stroke="#59634f" stroke-width="2" stroke-dasharray="4 7">${floor}</g>
      <g class="figure" fill="none" stroke="#b7f34b" stroke-width="11" stroke-linecap="round" stroke-linejoin="round" filter="url(#${filterId})">
        ${figure}
        ${horizontal ? `
          <g class="joints" fill="#b7f34b" stroke="#d9e8d0" stroke-width="2">
            <circle cx="75" cy="105" r="5"/><circle cx="52" cy="139" r="5"/>
            <circle cx="82" cy="106" r="5"/><circle cx="62" cy="143" r="5"/>
            <circle cx="110" cy="105" r="5"/><circle cx="143" cy="127" r="5"/>
            <circle cx="65" cy="104" r="5"/><circle cx="42" cy="130" r="5"/>
          </g>
          <path class="face" d="M153 96h1 M153 105q5 4 9 0" stroke="#111711" stroke-width="2.5" stroke-linecap="round"/>
          <path class="extremities" d="M22 165q-5 3-3 8 M176 159q5 3 7 7 M30 177h-9 M48 177h-9" stroke="#d9e8d0" stroke-width="5" stroke-linecap="round"/>
        ` : `
          <g class="joints" fill="#b7f34b" stroke="#d9e8d0" stroke-width="2">
            <circle cx="96" cy="72" r="5"/><circle cx="72" cy="100" r="5"/>
            <circle cx="104" cy="72" r="5"/><circle cx="128" cy="99" r="5"/>
            <circle cx="96" cy="119" r="5"/><circle cx="77" cy="160" r="5"/>
            <circle cx="104" cy="119" r="5"/><circle cx="124" cy="160" r="5"/>
          </g>
          <path class="face" d="M94 35h1 M105 35h1 M96 44q4 4 8 0" stroke="#111711" stroke-width="2.5" stroke-linecap="round"/>
          <path class="extremities" d="M69 202h-9q-5 0-6 4 M132 202h9q5 0 6 4" stroke="#d9e8d0" stroke-width="5" stroke-linecap="round"/>
        `}
      </g>
      <path class="headband" d="M86 34 Q100 23 114 34" fill="none" stroke="#d9e8d0" stroke-width="4" stroke-linecap="round"/>
      ${extra}
      <style>
        .athlete-svg .head{fill:#d9e8d0;stroke:#b7f34b;stroke-width:2}
        .athlete-svg .torso{stroke:#d9e8d0;stroke-width:17}
        .athlete-svg .ground{opacity:.8}.athlete-svg .mat{stroke:#59634f;stroke-width:3;fill:none}
        .athlete-svg .figure{transform-box:fill-box;transform-origin:center}
        .athlete-svg .arm,.athlete-svg .leg,.athlete-svg .torso{transform-box:fill-box;transform-origin:center}
        .athlete-idle .figure{animation:idleBreath 3s ease-in-out infinite}
        .athlete-pushup .torso{animation:pushTorso 2s ease-in-out infinite}
        .athlete-pushup .arm-a,.athlete-pushup .arm-b{animation:pushArms 2s ease-in-out infinite}
        .athlete-pushup .leg-a,.athlete-pushup .leg-b{animation:pushLegs 2s ease-in-out infinite}
        .athlete-pushup .head{animation:pushHead 2s ease-in-out infinite}
        .athlete-squat .figure{animation:squatBody 2.2s ease-in-out infinite}
        .athlete-squat .leg-a{animation:squatLeg 2.2s ease-in-out infinite}
        .athlete-squat .leg-b{animation:squatLegB 2.2s ease-in-out infinite}
        .athlete-situp .figure{animation:situpBody 2.4s ease-in-out infinite;transform-origin:100px 170px}
        .athlete-run .leg-a{animation:runA .55s ease-in-out infinite alternate}
        .athlete-run .leg-b{animation:runB .55s ease-in-out infinite alternate}
        .athlete-run .arm-a{animation:runB .55s ease-in-out infinite alternate}
        .athlete-run .arm-b{animation:runA .55s ease-in-out infinite alternate}
        .athlete-run .figure{animation:runBounce .55s ease-in-out infinite}
        .athlete-plank .figure{animation:plankHold 2.5s ease-in-out infinite}
        .athlete-mountain .leg-a{animation:mountainA .7s ease-in-out infinite alternate}
        .athlete-mountain .leg-b{animation:mountainB .7s ease-in-out infinite alternate}
        .athlete-lunge .leg-a{animation:lungeA 2.5s ease-in-out infinite}
        .athlete-lunge .leg-b{animation:lungeB 2.5s ease-in-out infinite}
        .athlete-lunge .torso{animation:lungeTorso 2.5s ease-in-out infinite}
        .athlete-stretch .arm-a{animation:stretchA 3s ease-in-out infinite alternate}
        .athlete-stretch .arm-b{animation:stretchB 3s ease-in-out infinite alternate}
        .athlete-bridge .figure{animation:bridgeMove 2.3s ease-in-out infinite;transform-origin:100px 170px}
        .athlete-calf .figure{animation:calfMove 1.8s ease-in-out infinite}
        .athlete-wall .figure{animation:wallHold 3s ease-in-out infinite}
        .athlete-bird .arm-a{animation:birdA 2s ease-in-out infinite alternate}
        .athlete-bird .leg-b{animation:birdB 2s ease-in-out infinite alternate}
        .athlete-superman .figure{animation:superman 2s ease-in-out infinite alternate}
        @keyframes idleBreath{50%{transform:translateY(-2px)}}
        @keyframes pushTorso{0%,100%{transform:translateY(0)}50%{transform:translateY(12px)}}
        @keyframes pushArms{0%,100%{transform:translateY(0)}50%{transform:translateY(7px) rotate(3deg)}}
        @keyframes pushLegs{0%,100%{transform:translateY(0)}50%{transform:translateY(2px)}}
        @keyframes pushHead{0%,100%{transform:translateY(0)}50%{transform:translateY(9px)}}
        @keyframes squatBody{0%,100%{transform:translateY(0) scaleY(1)}50%{transform:translateY(19px) scaleY(.9)}}
        @keyframes squatLeg{0%,100%{transform:rotate(0)}50%{transform:rotate(24deg)}}
        @keyframes squatLegB{0%,100%{transform:rotate(0)}50%{transform:rotate(-24deg)}}
        @keyframes situpBody{0%,100%{transform:rotate(0)}50%{transform:rotate(-38deg)}}
        @keyframes runA{from{transform:rotate(-32deg)}to{transform:rotate(36deg)}}
        @keyframes runB{from{transform:rotate(36deg)}to{transform:rotate(-32deg)}}
        @keyframes runBounce{50%{transform:translateY(-7px)}}
        @keyframes plankHold{50%{transform:translateY(-1px)}}
        @keyframes mountainA{from{transform:rotate(-48deg)}to{transform:rotate(35deg)}}
        @keyframes mountainB{from{transform:rotate(35deg)}to{transform:rotate(-48deg)}}
        @keyframes lungeA{0%,100%{transform:rotate(0)}50%{transform:rotate(38deg)}}
        @keyframes lungeB{0%,100%{transform:rotate(0)}50%{transform:rotate(-22deg)}}
        @keyframes lungeTorso{0%,100%{transform:translateY(0)}50%{transform:translateY(8px)}}
        @keyframes stretchA{to{transform:rotate(-38deg)}}@keyframes stretchB{to{transform:rotate(38deg)}}
        @keyframes bridgeMove{0%,100%{transform:translateY(0)}50%{transform:translateY(-13px)}}
        @keyframes calfMove{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
        @keyframes wallHold{50%{transform:translateY(3px)}}
        @keyframes birdA{to{transform:translateX(-12px) rotate(-8deg)}}@keyframes birdB{to{transform:translateX(13px) rotate(8deg)}}
        @keyframes superman{to{transform:translateY(-4px) scale(1.02)}}
        /* Exercise-specific coaching cycles. Each library entry gets its own cue. */
        .move-wide .arm-a{animation:wideArm 2.2s ease-in-out infinite}.move-wide .arm-b{animation:wideArm 2.2s ease-in-out infinite reverse}
        .move-pike .figure{animation:pikeHinge 2.4s ease-in-out infinite}.move-pike .head{animation:pikeHead 2.4s ease-in-out infinite}
        .move-close .arm-a,.move-close .arm-b{animation:closeArm 2s ease-in-out infinite}
        .move-jump .figure{animation:jumpCycle 1.5s cubic-bezier(.4,0,.2,1) infinite}.move-jump .leg-a{animation:jumpLeg 1.5s ease-in-out infinite}.move-jump .leg-b{animation:jumpLeg 1.5s ease-in-out infinite reverse}
        .move-calf .figure{animation:calfMove 1.7s ease-in-out infinite}
        .move-wall .figure{animation:wallHold 3s ease-in-out infinite}
        .move-high .figure{animation:runBounce .5s ease-in-out infinite}.move-high .leg-a{animation:runA .5s ease-in-out infinite alternate}.move-high .leg-b{animation:runB .5s ease-in-out infinite alternate}
        .move-fast .figure{animation:fastBounce .32s linear infinite}.move-fast .leg-a{animation:fastLeg .32s linear infinite alternate}.move-fast .leg-b{animation:fastLeg .32s linear infinite alternate-reverse}
        .move-start .figure{animation:startDrive .8s ease-in-out infinite alternate}.move-start .leg-a{animation:runA .55s ease-in-out infinite alternate}.move-start .leg-b{animation:runB .55s ease-in-out infinite alternate}
        .move-skater .figure{animation:skaterShift 1.7s ease-in-out infinite alternate}.move-skater .leg-a{animation:skaterLeg 1.7s ease-in-out infinite alternate}.move-skater .leg-b{animation:skaterLeg 1.7s ease-in-out infinite alternate-reverse}
        .move-crunch .figure{animation:crunchPulse 1.8s ease-in-out infinite;transform-origin:100px 170px}
        .move-legraise .leg-a,.move-legraise .leg-b{animation:legRaise 2.1s ease-in-out infinite;transform-origin:100px 160px}
        .move-side .figure{animation:sideHold 2.8s ease-in-out infinite}
        .move-curl .arm-a,.move-curl .arm-b{animation:curlArm 1.8s ease-in-out infinite}
        .move-march .leg-a{animation:marchA .75s ease-in-out infinite alternate}.move-march .leg-b{animation:marchB .75s ease-in-out infinite alternate}
        .move-walk .leg-a{animation:marchA 1.2s ease-in-out infinite alternate}.move-walk .leg-b{animation:marchB 1.2s ease-in-out infinite alternate}
        .move-stretch .figure{animation:stretchBody 3s ease-in-out infinite alternate}
        .move-bridge .figure{animation:bridgeMove 2.3s ease-in-out infinite;transform-origin:100px 170px}
        .move-bird .figure{animation:birdBalance 2.2s ease-in-out infinite alternate}
        .move-snow .arm-a,.move-snow .arm-b{animation:snowSweep 2.8s ease-in-out infinite alternate}
        @keyframes wideArm{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(8px) rotate(5deg)}}
        @keyframes pikeHinge{0%,100%{transform:translateY(0) scaleY(1)}50%{transform:translateY(-8px) scaleY(.9)}}@keyframes pikeHead{50%{transform:translateY(12px)}}
        @keyframes closeArm{0%,100%{transform:translateY(0)}50%{transform:translateY(9px)}}
        @keyframes jumpCycle{0%,35%,100%{transform:translateY(0)}55%{transform:translateY(-22px)}}@keyframes jumpLeg{50%{transform:rotate(12deg)}}
        @keyframes fastBounce{50%{transform:translateY(-3px)}}@keyframes fastLeg{to{transform:rotate(42deg)}}
        @keyframes startDrive{to{transform:translate(-5px,-5px) rotate(-7deg)}}
        @keyframes skaterShift{to{transform:translateX(15px)}}@keyframes skaterLeg{to{transform:rotate(28deg)}}
        @keyframes crunchPulse{0%,100%{transform:rotate(0)}50%{transform:rotate(-22deg)}}
        @keyframes legRaise{0%,100%{transform:rotate(0)}50%{transform:rotate(-28deg)}}
        @keyframes sideHold{50%{transform:translateY(-3px) rotate(-2deg)}}
        @keyframes curlArm{0%,100%{transform:rotate(0)}50%{transform:rotate(-32deg)}}
        @keyframes marchA{to{transform:rotate(-24deg)}}@keyframes marchB{to{transform:rotate(24deg)}}
        @keyframes stretchBody{to{transform:translateY(-4px)}}@keyframes birdBalance{to{transform:translateY(-3px) rotate(-2deg)}}@keyframes snowSweep{to{transform:rotate(-45deg)}}
        @media(prefers-reduced-motion:reduce){.athlete-svg *{animation:none!important}}
      </style></svg>`;
  }
};

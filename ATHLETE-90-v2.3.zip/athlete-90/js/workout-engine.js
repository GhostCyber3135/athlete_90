window.Workout = {
 state:null, clockInterval:null, restInterval:null, restDeadline:0, restRemaining:0, inRest:false,
 start(day){
  const plan=window.Plans[day];
  if(!plan){toast("برنامه این روز پیدا نشد.");return false}
  if(!Array.isArray(plan.items)||plan.items.length===0){toast("این روز برای ریکاوری است؛ جلسه تمرینی دیگری را انتخاب کن.");return false}
  const items=plan.items.map(id=>({exercise:Exercises.find(e=>e.id===id),done:0}));
  if(items.some(x=>!x.exercise)){toast("یکی از حرکات برنامه در کتابخانه پیدا نشد؛ برنامه را متوقف کردم.");return false}
  this.stopTimers();
  this.state={day,plan,items,index:0,set:1,completedSets:0,paused:false,elapsedMs:0,resumedAt:Date.now(),startedAt:Date.now()};
  this.render();this.startClock();return true
 },
 startToday(){
  const today=(new Date().getDay()+1)%7;
  if(window.Plans[today]?.items?.length)return this.start(today);
  const next=Array.from({length:7},(_,offset)=>(today+offset+1)%7).find(index=>window.Plans[index]?.items?.length);
  if(next===undefined){toast("برنامه تمرینی فعالی پیدا نشد.");return false}
  toast(`${window.Plans[today].day} روز ریکاوری است؛ جلسه ${window.Plans[next].day} را شروع می‌کنیم.`);
  return this.start(next);
 },
 current(){return this.state?.items[this.state.index]},
 elapsed(){const s=this.state;if(!s)return 0;return s.elapsedMs+(s.paused?0:Date.now()-s.resumedAt)},
 startClock(){clearInterval(this.clockInterval);if(!this.state||this.state.paused)return;this.clockInterval=setInterval(()=>{const el=document.getElementById("workoutClock");if(el)el.textContent=fmt(Math.floor(this.elapsed()/1000));},1000)},
 stopTimers(){clearInterval(this.clockInterval);clearInterval(this.restInterval);this.clockInterval=null;this.restInterval=null},
 render(){const s=this.state;if(!s)return;const item=this.current();if(!item){this.finish();return}const e=item.exercise;const total=s.items.reduce((n,x)=>n+x.exercise.sets,0);const progress=Math.round(s.completedSets/total*100);
 modal(`<div class="workout-top"><span class="eyebrow">WORKOUT IN PROGRESS</span><b class="workout-count" dir="ltr">${s.index+1} / ${s.items.length}</b></div><div class="workout-progress"><span style="width:${progress}%"></span></div><div class="workout-clock-row"><span>زمان تمرین</span><strong id="workoutClock" dir="ltr">${fmt(Math.floor(this.elapsed()/1000))}</strong></div>${videoPanel(e,"workout")}<div class="exercise-meta"><span>${e.cat} · ${e.en}</span><span>ست ${s.set} از ${e.sets}</span></div><h2 class="workout-title">${e.name}</h2><div class="workout-tip">${e.tip}</div><div class="counter-box"><div><small class="muted">هدف این ست</small><br><strong>${e.reps}</strong></div><div class="set-dots">${Array.from({length:e.sets},(_,i)=>`<i class="set-dot ${i<s.set-1?"done":""}"></i>`).join("")}</div></div><div class="workout-controls"><button class="btn btn-primary" id="completeSet" ${s.paused?"disabled":""}>ثبت پایان ست ✓</button><button class="btn btn-secondary" id="pauseWorkout">${s.paused?"ادامه":"مکث"}</button><button class="btn btn-ghost" id="skipExercise">رد کردن حرکت</button></div><div class="workout-controls"><button class="btn btn-ghost" id="stopWorkout">پایان تمرین</button></div><p class="muted" style="font-size:10px;margin-top:12px">تکرارها را با فرم صحیح انجام بده. در صورت درد، سرگیجه یا تنگی نفس غیرعادی تمرین را متوقف کن.</p>`);
  document.getElementById("completeSet").onclick=()=>this.completeSet();
  document.getElementById("pauseWorkout").onclick=()=>this.togglePause();
  document.getElementById("skipExercise").onclick=()=>{if(this.state?.paused){toast("برای ادامه یا رد حرکت، ابتدا تمرین را ادامه بده.");return}this.indexNext()};
  document.getElementById("stopWorkout").onclick=()=>{if(confirm("تمرین نیمه‌تمام بسته شود؟ فقط ست‌های ثبت‌شده ذخیره می‌شوند."))this.finish(true)};
 },
 togglePause(){const s=this.state;if(!s)return;if(!s.paused){s.elapsedMs+=Date.now()-s.resumedAt;s.paused=true;clearInterval(this.clockInterval);clearInterval(this.restInterval);if(this.restDeadline)this.restRemaining=Math.max(0,Math.ceil((this.restDeadline-Date.now())/1000));this.restDeadline=0;this.renderPausedState();}else{s.paused=false;s.resumedAt=Date.now();this.startClock();if(this.inRest){this.renderRest();this.startRestCountdown()}else this.render();}},
 renderPausedState(){
  if(this.inRest){const b=document.getElementById("pauseFromRest");if(b)b.textContent="ادامه تمرین";const c=document.getElementById("skipRest");if(c)c.textContent="در حالت مکث";const clock=document.getElementById("restClock");if(clock)clock.textContent=fmt(this.restRemaining)}
  else{const b=document.getElementById("pauseWorkout"),c=document.getElementById("completeSet");if(b)b.textContent="ادامه";if(c)c.disabled=true;const e=document.getElementById("workoutClock");if(e)e.textContent=fmt(Math.floor(this.elapsed()/1000))}
  toast("تمرین متوقف شد.")
 },
 indexNext(){const s=this.state;if(!s)return;s.index++;s.set=1;if(s.index>=s.items.length)this.finish();else this.render()},
 completeSet(){const s=this.state,item=this.current();if(!s||!item||s.paused)return;item.done++;s.completedSets++;if(s.set>=item.exercise.sets){s.index++;s.set=1;if(s.index>=s.items.length){this.finish();return}}else{s.set++}this.rest(item.exercise.rest)},
 rest(sec){if(!this.state)return;if(!Store.data.settings.rest||sec<=0){this.inRest=false;this.render();return}this.inRest=true;this.restRemaining=Store.data.settings.restDuration!==60?Store.data.settings.restDuration:sec;this.renderRest();if(!this.state.paused)this.startRestCountdown()},
 renderRest(){const left=this.restRemaining;modal(`<div class="workout-top"><span class="eyebrow">RECOVERY</span><b>استراحت بین ست‌ها</b></div><div class="rest-visual">بدنت را رها کن و آرام نفس بکش.</div><div style="text-align:center"><div class="timer-display" id="restClock" dir="ltr">${fmt(left)}</div><p class="muted">نفس را آرام کن و برای ست بعد آماده شو.</p><button class="btn btn-primary" id="skipRest">${this.state?.paused?"در حالت مکث":"ادامه تمرین"}</button><button class="btn btn-ghost" id="pauseFromRest">${this.state?.paused?"ادامه تمرین":"مکث"}</button></div>`);document.getElementById("skipRest").onclick=()=>{if(this.state?.paused)return toast("ابتدا تمرین را ادامه بده.");this.restRemaining=0;clearInterval(this.restInterval);this.render()};document.getElementById("pauseFromRest").onclick=()=>this.togglePause()},
 startRestCountdown(){clearInterval(this.restInterval);if(!this.state||this.state.paused||this.restRemaining<=0)return;this.restDeadline=Date.now()+this.restRemaining*1000;this.restInterval=setInterval(()=>{this.restRemaining=Math.max(0,Math.ceil((this.restDeadline-Date.now())/1000));const clock=document.getElementById("restClock");if(clock)clock.textContent=fmt(this.restRemaining);if(this.restRemaining<=0){clearInterval(this.restInterval);this.restInterval=null;this.restDeadline=0;this.inRest=false;if(Store.data.settings.sound)beep();this.render()}},250)},
 finish(partial=false){this.stopTimers();this.inRest=false;const s=this.state;if(!s)return;const minutes=Math.max(1,Math.round(this.elapsed()/60000));if(s.completedSets>0){Store.addSession({date:localDate(),day:s.day,title:s.plan.title,minutes,sets:s.completedSets,partial});renderAll();toast(partial?"تمرین ناقص ذخیره شد":"تمرین ثبت شد؛ آفرین!")};this.state=null;this.restRemaining=0;this.inRest=false;closeModal()},
};
function fmt(n){return `${String(Math.floor(n/60)).padStart(2,"0")}:${String(n%60).padStart(2,"0")}`}
function beep(){try{const c=new AudioContext(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=660;g.gain.value=.06;o.start();o.stop(c.currentTime+.15)}catch(e){}}

window.Store = {
 key:"athlete90_v1",
 data:{sessions:[],records:{pushups:0,squats:0,situps:0,plank:0},journal:"",settings:{sound:true,rest:true,restDuration:60,theme:"dark"},completedDays:[],draft:null},
 load(){try{const x=JSON.parse(localStorage.getItem(this.key)||"null");if(x)this.data={...this.data,...x,settings:{...this.data.settings,...(x.settings||{})},records:{...this.data.records,...(x.records||{})}}}catch(e){console.warn("Storage load",e)}return this.data},
 save(){localStorage.setItem(this.key,JSON.stringify(this.data))},
 addSession(s){this.data.sessions.unshift(s);this.data.completedDays=[...new Set([...this.data.completedDays,s.date])];this.save()},
 getStats(){const sessions=this.data.sessions;return{workouts:sessions.length,minutes:sessions.reduce((a,s)=>a+(s.minutes||0),0),sets:sessions.reduce((a,s)=>a+(s.sets||0),0),streak:this.streak()}},
 streak(){let d=new Date(),n=0;const days=new Set(this.data.completedDays);for(let i=0;i<366;i++){const k=localDate(d);if(days.has(k)){n++;d.setDate(d.getDate()-1)}else if(i===0){d.setDate(d.getDate()-1);if(!days.has(localDate(d)))break}else break}return n},
 export(){const blob=new Blob([JSON.stringify(this.data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="athlete-90-backup.json";a.click();URL.revokeObjectURL(a.href)},
 import(obj){if(!obj||!Array.isArray(obj.sessions)||!obj.records)throw Error("فایل پشتیبان معتبر نیست");this.data={...this.data,...obj};this.save()}
};
function localDate(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
window.localDate=localDate;
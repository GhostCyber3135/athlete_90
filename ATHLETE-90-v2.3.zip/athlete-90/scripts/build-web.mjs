import { cp, mkdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'www');
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const entry of ['index.html', 'styles.css', 'app.js', 'manifest.json', 'service-worker.js', 'assets', 'js']) {
  await cp(path.join(root, entry), path.join(out, entry), { recursive: true });
}
console.log('Web assets copied to www/');

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const root = path.resolve(__dirname, "..");
const read = (p) => fs.readFileSync(path.join(root, p), "utf8");

function createContext() {
  const ctx = {
    console, Date, Math, Array, Set, Intl,
    clearInterval() {},
    setInterval() { return 1; },
    document: {
      els: {},
      getElementById(id) {
        return this.els[id] || (this.els[id] = { textContent: "", onclick: null });
      }
    },
    Plans: {
      0: { day: "شنبه", title: "جلسه آزمایشی", items: ["pushup"] },
      6: { day: "جمعه", title: "ریکاوری", items: [] }
    },
    Store: {
      data: { settings: { rest: false, restDuration: 60, sound: false } },
      addSession(session) { this.lastSession = session; },
      load() {}
    },
    toast(message) { ctx.lastToast = message; },
    modal(html) {
      ctx.lastModal = html;
      for (const id of ["completeSet", "pauseWorkout", "skipExercise", "stopWorkout"]) {
        ctx.document.els[id] = { textContent: "", onclick: null };
      }
    },
    videoPanel(exercise) { return ctx.Character.svg(exercise.type); },
    closeModal() { ctx.didClose = true; },
    renderAll() {},
    localDate() { return "2026-11-21"; }
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(read("js/animation-engine.js"), ctx);
  vm.runInContext(read("js/exercise-library.js"), ctx);
  vm.runInContext(read("js/workout-engine.js"), ctx);
  return ctx;
}

test("every planned exercise exists in the exercise library", () => {
  const ctx = createContext();
  vm.runInContext(read("app.js").split("Store.load();")[0], ctx);
  const ids = new Set(ctx.Exercises.map((exercise) => exercise.id));
  for (const [day, plan] of Object.entries(ctx.Plans)) {
    for (const id of plan.items) assert.ok(ids.has(id), `missing exercise ${id} in day ${day}`);
  }
});

test("animated guide renders for every movement type", () => {
  const ctx = createContext();
  const types = [...new Set(ctx.Exercises.map((exercise) => exercise.type))];
  for (const type of types) assert.match(ctx.Character.svg(type), /<svg[\s>]/, `no SVG for ${type}`);
});

test("rest day is rejected clearly; workout starts and saves a completed set", () => {
  const ctx = createContext();
  assert.equal(ctx.Workout.start(6), false);
  assert.match(ctx.lastToast, /ریکاوری/);
  assert.equal(ctx.Workout.start(0), true);
  assert.match(ctx.lastModal, /<svg/);
  ctx.document.els.completeSet.onclick();
  ctx.document.els.completeSet.onclick();
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state, null);
  assert.equal(ctx.Store.lastSession.sets, 3);
  assert.equal(ctx.didClose, true);
});


test("home start button starts the next workout on a rest day", () => {
  const ctx = createContext();
  const NativeDate = Date;
  class Friday extends NativeDate {
    getDay() { return 5; }
  }
  ctx.Date = Friday;
  assert.equal(ctx.Workout.startToday(), true);
  assert.equal(ctx.Workout.state.day, 0);
  assert.match(ctx.lastToast, /جمعه.*شنبه/);
});

test("each library exercise has its own coach animation identity", () => {
  const ctx = createContext();
  const ids = new Set();
  for (const exercise of ctx.Exercises) {
    const svg = ctx.Character.svg(exercise.id);
    assert.match(svg, new RegExp(`move-${exercise.id}(?:\\s|\\")`), `missing unique coach class for ${exercise.id}`);
    ids.add(exercise.id);
  }
  assert.equal(ids.size, ctx.Exercises.length);
});

test("pause blocks set completion and resume restores workout controls", () => {
  const ctx = createContext();
  assert.equal(ctx.Workout.start(0), true);
  ctx.document.els.pauseWorkout.onclick();
  assert.equal(ctx.Workout.state.paused, true);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state.completedSets, 0);
  ctx.document.els.pauseWorkout.onclick();
  assert.equal(ctx.Workout.state.paused, false);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.state.completedSets, 1);
});

test("rest countdown can be paused and resumed without losing its remaining time", () => {
  const ctx = createContext();
  ctx.Store.data.settings.rest = true;
  assert.equal(ctx.Workout.start(0), true);
  ctx.document.els.completeSet.onclick();
  assert.equal(ctx.Workout.inRest, true);
  const before = ctx.Workout.restRemaining;
  ctx.document.els.pauseFromRest.onclick();
  assert.equal(ctx.Workout.state.paused, true);
  assert.ok(ctx.Workout.restRemaining <= before);
  ctx.document.els.pauseFromRest.onclick();
  assert.equal(ctx.Workout.state.paused, false);
  assert.equal(ctx.Workout.inRest, true);
  ctx.Workout.finish(true);
});
